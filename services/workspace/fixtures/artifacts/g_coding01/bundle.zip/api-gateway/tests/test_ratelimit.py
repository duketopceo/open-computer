from gateway.ratelimit import TokenBucket


class FakeClock:
    def __init__(self):
        self.now = 0.0

    def __call__(self):
        return self.now


def test_refills_after_wait():
    clock = FakeClock()
    b = TokenBucket(rate=10, burst=1, clock=clock)
    assert b.allow()
    assert not b.allow()
    clock.now += 0.1
    assert b.allow()
